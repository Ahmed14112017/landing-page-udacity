# Landing Page Project

## Table of Contents

## Language used in this project:
* - HTML 
* - CSS
* - JAVASCRIPT
#  this project has Navigation is built dynamically as an unordered list.


# the first part
# in project about defination and creation variable and include for()loop to every section to add event
# this event when i clicked on (a) it will scroll to section.

# the second part 
# in project it about window scroll to foucs in section that i look to it

# method used:

## addEventListener()
## scrollIntoView()

# add active class to section that i click to it

# the second part :
## resposive web site with screen
