/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav


// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active
/*
first 
we define sections to can access to it
we define to ul element by id to can access 
we define to ul element by class name  to can access
*/

var mysection = document.querySelectorAll("section"); 
var ullist =document.getElementById("navbar__list");
var navbarmenu=document.getElementsByClassName("navbar__menu");
var navbigbar =document.getElementsByTagName("nav");
var fragment = document.createDocumentFragment();


/*
make for loop to have event for all section
make four element (li)
make four element (a)
get getAttribute for all section to be as text 
append li inside ul
append a inside li
append data-nav text inside a
add classlist for li a 
*/
    for (var i=0;i<mysection.length;i++){
        var lilist=document.createElement("li");
        var lilistlink = document.createElement("a");
        var datanav = mysection[i].getAttribute("data-nav");
        var navsec=document.createTextNode(datanav);
        ullist.appendChild(lilist);
        lilist.appendChild(lilistlink);
        lilistlink.appendChild(navsec);
        
        lilistlink.classList.add("menu__link");
        console.log(lilist);
        /*
        we use add eventlistener to make event scroll
        and we get id by delete any space in data nav text in all sections to conect a by section tag
        and ws used scrollIntoView to have behavior smooth in scroll
        */
        lilistlink.addEventListener("click", function (e) {
            console.log(e);
            document.getElementById(e.target.innerText.replace(/\s/g, "").toLowerCase())
            .scrollIntoView({ behavior: "smooth" });
            });
        fragment.appendChild(lilist);
    }
    
    ullist.appendChild(fragment)
    
    
/*
we used addEventListener to have event (scroll) and do function for all section by used (for each)
and get top of sections by used (getBoundingClientRect)
and define top we need to have event that is add active class
*/
window.addEventListener("scroll",function(){
    mysection.forEach(function(ele){
        let bondvalue=ele.getBoundingClientRect();
        console.log(bondvalue);
        if(bondvalue.top>0&&bondvalue.top<640){
            mysection.forEach(function(nonactive){
                nonactive.classList.add("your-active-class");
            })
        } 
        ele.classList.remove("your-active-class"); 
        

    })
})

/*
we used addEventListener to have event click to add class name (toggle)
that is show and disappear nav list 
*/
var menubar = document.getElementById("menubar");
menubar.addEventListener("click",function(){
    ullist.classList.toggle("toggle");
})

